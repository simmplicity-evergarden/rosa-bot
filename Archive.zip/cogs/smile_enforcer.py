from discord.ext import tasks, commands
from discord import app_commands
import re
import os
import discord
import logging
from string import ascii_uppercase
#from random import randint
from random import choices
from typing import Literal
#from typing import Optional
import configparser

logger = logging.getLogger('bot')

class Smile_Enforcer_Cog(commands.Cog):

	def __init__(self, bot):
		self.bot = bot
		# Load config
		self.config = configparser.ConfigParser()
		self.config.read(os.path.dirname(__file__)+os.path.sep+'..'+os.path.sep+'config.ini')
		logger.info('Loaded Smile Enforcer')

	# Run message relay
	@commands.Cog.listener()
	async def on_message(self, message):

		# Toy role check
		mod_role = message.guild.get_role(self.config.getint('roles','toy_role'))
		if mod_role not in message.author.roles:
			return

		message_content = message.content
		print(message_content)

		if re.search(r"\*\*Smile!~\*\*",message_content) == None:
			await message.delete()
			#await message.reply("Don't forget to **Smile!~**")
